package com.haroot.mybatis;

public class EvalStateViewDTO {

	private String walkroom_code, participants_code, mem_nickname, sid_code
	, walkroom_leader, mem_id, match_code
	, eval_writer, eval_target;

	public String getWalkroom_code()
	{
		return walkroom_code;
	}

	public void setWalkroom_code(String walkroom_code)
	{
		this.walkroom_code = walkroom_code;
	}

	public String getParticipants_code()
	{
		return participants_code;
	}

	public void setParticipants_code(String participants_code)
	{
		this.participants_code = participants_code;
	}

	public String getMem_nickname()
	{
		return mem_nickname;
	}

	public void setMem_nickname(String mem_nickname)
	{
		this.mem_nickname = mem_nickname;
	}

	public String getSid_code()
	{
		return sid_code;
	}

	public void setSid_code(String sid_code)
	{
		this.sid_code = sid_code;
	}

	public String getWalkroom_leader()
	{
		return walkroom_leader;
	}

	public void setWalkroom_leader(String walkroom_leader)
	{
		this.walkroom_leader = walkroom_leader;
	}

	public String getMem_id()
	{
		return mem_id;
	}

	public void setMem_id(String mem_id)
	{
		this.mem_id = mem_id;
	}

	public String getMatch_code()
	{
		return match_code;
	}

	public void setMatch_code(String match_code)
	{
		this.match_code = match_code;
	}

	public String getEval_writer()
	{
		return eval_writer;
	}

	public void setEval_writer(String eval_writer)
	{
		this.eval_writer = eval_writer;
	}

	public String getEval_target()
	{
		return eval_target;
	}

	public void setEval_target(String eval_target)
	{
		this.eval_target = eval_target;
	}
}
