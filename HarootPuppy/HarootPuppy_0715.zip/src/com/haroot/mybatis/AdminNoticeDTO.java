package com.haroot.mybatis;

public class AdminNoticeDTO
{
	private String notice_code
				, notice_writer
				, notice_head_code
				, notice_cate_content
				, notice_title
				, notice_photo
				, notice_content
				, notice_view
				, notice_like
				, notice_date;

	// getter, setter 생성
	public String getNotice_code()
	{
		return notice_code;
	}

	public void setNotice_code(String notice_code)
	{
		this.notice_code = notice_code;
	}

	public String getNotice_writer()
	{
		return notice_writer;
	}

	public void setNotice_writer(String notice_writer)
	{
		this.notice_writer = notice_writer;
	}

	public String getNotice_head_code()
	{
		return notice_head_code;
	}

	public void setNotice_head_code(String notice_head_code)
	{
		this.notice_head_code = notice_head_code;
	}

	public String getNotice_cate_content()
	{
		return notice_cate_content;
	}

	public void setNotice_cate_content(String notice_cate_content)
	{
		this.notice_cate_content = notice_cate_content;
	}

	public String getNotice_title()
	{
		return notice_title;
	}

	public void setNotice_title(String notice_title)
	{
		this.notice_title = notice_title;
	}

	public String getNotice_photo()
	{
		return notice_photo;
	}

	public void setNotice_photo(String notice_photo)
	{
		this.notice_photo = notice_photo;
	}

	public String getNotice_content()
	{
		return notice_content;
	}

	public void setNotice_content(String notice_content)
	{
		this.notice_content = notice_content;
	}

	public String getNotice_view()
	{
		return notice_view;
	}

	public void setNotice_view(String notice_view)
	{
		this.notice_view = notice_view;
	}

	public String getNotice_like()
	{
		return notice_like;
	}

	public void setNotice_like(String notice_like)
	{
		this.notice_like = notice_like;
	}

	public String getNotice_date()
	{
		return notice_date;
	}

	public void setNotice_date(String notice_date)
	{
		this.notice_date = notice_date;
	}
	
	
	
	
}
