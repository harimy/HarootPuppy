package com.haroot.mybatis;

public @interface Inject
{

}
