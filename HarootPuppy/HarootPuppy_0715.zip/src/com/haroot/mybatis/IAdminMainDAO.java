/*=================
 * ISampleDAO.java
 * - 인터페이스
==================*/
package com.haroot.mybatis;

public interface IAdminMainDAO
{

}
